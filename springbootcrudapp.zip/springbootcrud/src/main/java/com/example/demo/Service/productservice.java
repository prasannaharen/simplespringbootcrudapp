package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.product;
import com.example.demo.Repository.productrepository;

@Service
public class productservice {
	@Autowired
	private productrepository repo;
	
	public void pdtadd(product p) {
		repo.save(p);
	}
	
	public List<product> getallproducts(){
		return repo.findAll();
	}
	
	public product getproductbyid(int id) {
		return repo.findById(id).get();
	}
	public void deletebyid(int id) {
		repo.deleteById(id);
	}
	

}
