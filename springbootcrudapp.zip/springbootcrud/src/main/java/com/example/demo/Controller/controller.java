package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.Entity.product;
import com.example.demo.Service.productservice;


@Controller
public class controller {
	@Autowired
	
	private productservice serv;
	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/addproducts")
	public String addproducts() {
		return "addproducts";
	}
	
	@PostMapping("/save")
	public String saveproduct(@ModelAttribute product p) {
		serv.pdtadd(p);
		return "redirect:/viewproducts";
	}
	
	@GetMapping("/viewproducts")
	public ModelAndView viewproducts() {
		List<product> pdt=serv.getallproducts();
//		ModelAndView m=new ModelAndView();
//		m.setViewName("bookList");
//		m.addObject("book",list);
		//new ModelAndView("htmlpagename","obj used on the page",listobj)
		return new ModelAndView("viewproducts","pdt",pdt);
	}
	
	@GetMapping("/editpdt/{id}")
	public String editpdt(@PathVariable("id") int id,Model model) {
		product p=serv.getproductbyid(id);
		model.addAttribute("pdt",p);
		return "editproduct";
	}
	@GetMapping("/deletepdt/{id}")
	public String deletepdt(@PathVariable("id")int id) {
		serv.deletebyid(id);
		return "redirect:/viewproducts";
	}
	
	
	
}
